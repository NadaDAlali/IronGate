package main;

public abstract class Info {
    public abstract void viewInfo();
    public abstract void editInformation();
}