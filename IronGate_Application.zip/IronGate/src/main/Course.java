package main;

public class Course{
    //Data fields
    public String name;
    public int level;
    
    //Constructor
    Course(String name, int level){
        this.name = name;
        this.level = level;
    }
    
} //end of Course class